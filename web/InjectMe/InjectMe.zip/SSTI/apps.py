from django.apps import AppConfig


class SstiConfig(AppConfig):
    name = 'SSTI'
